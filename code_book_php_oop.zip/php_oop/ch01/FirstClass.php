<?php

class FirstClass {
    
}

$firstClass = new FirstClass();
echo gettype($firstClass);
?>
