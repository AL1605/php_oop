<?php
define('SCRIPTPATH','/php_oop/phpChart_Lite/');
define('DEBUG', false);

/******** DO NOT MODIFY ***********/
require_once('phpChart.php');     
/**********************************/
?>
