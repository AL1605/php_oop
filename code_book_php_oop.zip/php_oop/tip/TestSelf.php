<?php
include_once 'B.php';
B::methodB();
?>

