<?php

class Admin {
    public $id;
    public $admin_username;
    public $admin_password;
    public $admin_name;
}
?>
