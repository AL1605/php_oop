<?php

class Orders {
    
    public $id;
    public $product_id;
    public $order_price;
    public $bill_id;
    public $order_status;
}
?>
