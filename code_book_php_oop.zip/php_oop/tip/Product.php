<?php

class Product {
    
    public $id;
    public $name;
    public $detail;
    public $price;
    public $image;
    public $created_date;
    public $status;
}
?>
