<?php

class Bill {
    
    public $id;
    public $created_date;
    public $customer_name;
    public $customer_tel;
    public $customer_address;
    public $bill_status;
}
?>
