<?php

include_once 'Ball.php';

Ball::test();
?>

