<form method="post" action="TestLogin.php">
    <div>Username: <input type="text" name="admin_username" /></div>
    <div>Password: <input type="password" name="admin_password" /></div>
    <div><input type="submit" value="Login Now" /></div>
</form>