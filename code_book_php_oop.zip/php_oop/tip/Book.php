<?php

class Book {
    public $isbn;
    public $name;
    public $price;
    public $page;
    public $bookType;
}
?>
