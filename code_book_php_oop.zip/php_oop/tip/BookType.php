<?php

class BookType {
    public $id;
    public $name;
}
?>
