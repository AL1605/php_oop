<div class="footer">
    ร้านค้า javathailand โทร. 086 877 6053, email: thekaroe@hotmail.com<br />
    ขับเคลื่อนโดย PHP OOP + MySQL
</div>
