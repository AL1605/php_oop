<form method="post" action="insert.php">
    name: <input type="text" name="name" /><br />
    price: <input type="text" name="price" /><br />
    page: <input type="text" name="page" /><br />
    <input type="submit" value="Save" />
</form>

